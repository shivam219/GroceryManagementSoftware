use world;
create table Gvegetable( pid int auto_increment primary key, pname varchar(50) not null, pack varchar(10) not null,
quantity int not null,price int not null);
desc Gvegetable;
insert into Gvegetable (pname,pack,quantity,price) values ('tomato','1kg',50,40),
('sweet potato','1kg',40,30),
('onion','1kg',60,25),
('ginger','250gm',80,20);
select*from Gvegetable;


drop table Gvegetable;
commit;