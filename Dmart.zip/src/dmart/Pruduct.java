package dmart;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedHashMap;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class Pruduct extends javax.swing.JFrame {
    
    Statement st = ConnectionProvider.getStatement();
    DefaultTableModel bilTableModel;
    LinkedHashMap<Integer, Integer> map = new LinkedHashMap<Integer, Integer>();
    int TotalPriceOfQuantity = 0, TotalCountOfQuantity = 0, OrderID = 0;
    boolean isEnter = false;
    
    public Pruduct() {
        initComponents();
        setLocationRelativeTo(null);
        setDataToVegitable();
        bilTableModel = (DefaultTableModel) jtablebiliing.getModel();
        getOrderId();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnBuy = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btnRefresh1 = new javax.swing.JButton();
        lblTotalAmt = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jtfEnterQTYVegitable = new javax.swing.JTextField();
        jtfEnterIdVegitable = new javax.swing.JTextField();
        labelPId = new javax.swing.JLabel();
        btnVegitableAddToCart = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtableVegitable = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtablebiliing = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        btnBuy.setBackground(new java.awt.Color(0, 153, 102));
        btnBuy.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnBuy.setForeground(new java.awt.Color(255, 255, 255));
        btnBuy.setText("Buy");
        btnBuy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuyActionPerformed(evt);
            }
        });

        btnRefresh.setBackground(new java.awt.Color(0, 153, 102));
        btnRefresh.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        btnRefresh.setForeground(new java.awt.Color(255, 255, 255));
        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Billing section");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 153, 102));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/shope2.png"))); // NOI18N
        jLabel7.setText("GroceryMart");

        btnRefresh1.setBackground(new java.awt.Color(0, 153, 102));
        btnRefresh1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnRefresh1.setForeground(new java.awt.Color(255, 255, 255));
        btnRefresh1.setText("Back");
        btnRefresh1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefresh1ActionPerformed(evt);
            }
        });

        lblTotalAmt.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTotalAmt.setText("Totol amount >>");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Enter Quantity >>");

        labelPId.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelPId.setText("Enter product ID >>");

        btnVegitableAddToCart.setBackground(new java.awt.Color(0, 153, 102));
        btnVegitableAddToCart.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnVegitableAddToCart.setForeground(new java.awt.Color(255, 255, 255));
        btnVegitableAddToCart.setText("Add to cart");
        btnVegitableAddToCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVegitableAddToCartActionPerformed(evt);
            }
        });

        jtableVegitable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product ID", "Name", "Pack", "Quantity", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jtableVegitable);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(0, 126, Short.MAX_VALUE)
                        .addComponent(labelPId, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jtfEnterIdVegitable, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtfEnterQTYVegitable, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addComponent(btnVegitableAddToCart)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 522, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jtfEnterIdVegitable, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(labelPId))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(jtfEnterQTYVegitable, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnVegitableAddToCart))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Products list", jPanel3);

        jtablebiliing.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "P ID", "Name", "Pack", "QTY", "Price", "Sub Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jtablebiliing);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 722, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblTotalAmt, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnRefresh)
                                        .addGap(134, 134, 134)
                                        .addComponent(btnBuy, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnRefresh1))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 541, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 451, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTotalAmt, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuy, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRefresh1)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void getOrderId() {
        ResultSet rs = null;
        try {
            rs = st.executeQuery("select * from OrderHistory");
            if (rs != null) {
                while (rs.next()) {
                    OrderID = rs.getInt(1) + 1;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
    public void setDataToVegitable() {
        try {
            jtableVegitable.setModel(DbUtils.resultSetToTableModel(st.executeQuery("select * from Gvegetable")));
            DefaultTableModel model = (DefaultTableModel) jtableVegitable.getModel();
            model.setColumnIdentifiers(new String[]{"Product ID", "Name", "Pack", "Quantity", "Price"});
        } catch (Exception e) {
        }
    }
    private void btnRefresh1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefresh1ActionPerformed
        dispose();
        new Login().setVisible(true);
    }//GEN-LAST:event_btnRefresh1ActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        bilTableModel.setRowCount(0);

    }//GEN-LAST:event_btnRefreshActionPerformed

    private void btnVegitableAddToCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVegitableAddToCartActionPerformed
        if (!jtfEnterIdVegitable.getText().isEmpty() && !jtfEnterIdVegitable.getText().isBlank() && !jtfEnterQTYVegitable.getText().isEmpty() && !jtfEnterQTYVegitable.getText().isBlank()) {
            int jtfid = 0, jtfQty = 0;
            boolean pidFound = false;
            DefaultTableModel model = (DefaultTableModel) jtableVegitable.getModel();
            boolean isAllReady = false;
            try {
                jtfid = Integer.parseInt(jtfEnterIdVegitable.getText());
                jtfQty = Integer.parseInt(jtfEnterQTYVegitable.getText());
                for (int i = 0; i < model.getRowCount(); i++) {
                    int tid = Integer.parseInt(model.getValueAt(i, 0).toString());
                    int tQty = Integer.parseInt(model.getValueAt(i, 3).toString());
                    if (tid == jtfid) {
                        pidFound = true;
                        if (tQty >= jtfQty) {
                            model.setValueAt(tQty - jtfQty, i, 3);
                            map.put(tid, tQty - jtfQty);
                            String name = model.getValueAt(i, 1).toString();
                            String pack = model.getValueAt(i, 2).toString();
                            int price = Integer.parseInt(model.getValueAt(i, 4).toString());
                            int totalPrice = jtfQty * price;
                            
                            for (int j = 0; j < bilTableModel.getRowCount(); j++) {
                                if (bilTableModel.getValueAt(j, 0).toString().equals(tid + "")) {
                                    int Quantity = Integer.parseInt(bilTableModel.getValueAt(j, 3).toString()) + jtfQty;
                                    bilTableModel.setValueAt(Quantity, j, 3);
                                    bilTableModel.setValueAt(price * Quantity, j, 5);
                                    isAllReady = true;
                                    TotalPriceOfQuantity = TotalPriceOfQuantity + (price * jtfQty);
                                    TotalCountOfQuantity = TotalCountOfQuantity + jtfQty;
                                }
                            }
                            if (!isAllReady) {
                                bilTableModel.addRow(new String[]{tid + "", name, pack, jtfQty + "", price + "", totalPrice + ""});
                                TotalPriceOfQuantity = TotalPriceOfQuantity + totalPrice;
                                TotalCountOfQuantity = TotalCountOfQuantity + jtfQty;
                                
                            }
                            lblTotalAmt.setText("Totol amount >> " + TotalPriceOfQuantity);
                            
                        } else {
                            JOptionPane.showMessageDialog(this, "Encefient Quantity");
                        }
                    }
                }
                if (!pidFound) {
                    JOptionPane.showMessageDialog(this, "Product Id not founded");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Enter Valid data");
            }
        }
    }//GEN-LAST:event_btnVegitableAddToCartActionPerformed

    private void btnBuyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuyActionPerformed
        String amt = JOptionPane.showInputDialog(this, "Enter Amount", "Grossery-Mart Billing", JOptionPane.PLAIN_MESSAGE);
        if (amt != null && !amt.isEmpty() && !amt.isBlank()) {
            try {
                int amount = Integer.parseInt(amt);
                if (amount > TotalPriceOfQuantity) {
                    JOptionPane.showMessageDialog(this, "Payment Done\nReturn " + (amount - TotalPriceOfQuantity), "Successful", JOptionPane.PLAIN_MESSAGE);
                    new OrderPlace(jtablebiliing, TotalPriceOfQuantity, OrderID, TotalCountOfQuantity, map).setVisible(true);
                    dispose();
                } else if (amount < TotalPriceOfQuantity) {
                    JOptionPane.showMessageDialog(this, "Payment failed", "Failed", JOptionPane.WARNING_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Payment Done", "Successful", JOptionPane.PLAIN_MESSAGE);
                    new OrderPlace(jtablebiliing, TotalPriceOfQuantity, OrderID, TotalCountOfQuantity, map).setVisible(true);
                    dispose();
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Please Enter Digit", "Warring", JOptionPane.WARNING_MESSAGE);
            }
        }
    }//GEN-LAST:event_btnBuyActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pruduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pruduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pruduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pruduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pruduct().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuy;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnRefresh1;
    private javax.swing.JButton btnVegitableAddToCart;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jtableVegitable;
    private javax.swing.JTable jtablebiliing;
    private javax.swing.JTextField jtfEnterIdVegitable;
    private javax.swing.JTextField jtfEnterQTYVegitable;
    private javax.swing.JLabel labelPId;
    private javax.swing.JLabel lblTotalAmt;
    // End of variables declaration//GEN-END:variables
}
