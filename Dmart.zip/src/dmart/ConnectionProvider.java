package dmart;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
//import com.mysql.cj.jdbc.Driver;1 either 2

public class ConnectionProvider {

    private ConnectionProvider() {
    }
    static Statement st = null;    
    static Connection con =null;


    public static synchronized Statement getStatement() {
        synchronized (ConnectionProvider.class) {
            if (st == null) {
                try {
                    /* Class.forName("com.mysql.jdbc.Driver"); dont we this line*/
                    Class.forName("com.mysql.cj.jdbc.Driver");// 2 eithe 1
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/world", "root", "Mysql111");
                    st = con.createStatement();
                     
                } catch (Exception e) {e.printStackTrace();}
                return st;
            }
            return st;
        }
    }
    public static void main(String[] args) {
        Statement st = ConnectionProvider.getStatement();
        ResultSet rs = null;
        try {
            if (st != null) {
                rs = st.executeQuery("select * from cuser");
            }
            if (rs != null) {
                while (rs.next()) {
                    System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getInt(3));
                }
            }
        } catch (Exception e) {

        }

    }
}
