create table manager (eid int primary key auto_increment,fname varchar(30), lname varchar(30) ,phone int(10) , password varchar(30)) ;
use world;
show databases;
insert into manager (fname, lname, phone, password) value('shivam' ,'choudhary',889451254 ,'shivam@219');

select * from manager;
select cid from manager lastrow ;
desc manager;
select * from manager where eid=1 and password='shivam@219';
desc manager;

insert into manager (fname, lname, phone, password) value('suraj' ,'choudhary',864 ,'suraj@219');
insert into manager (fname, lname, phone, password) value('deepak' ,'choudhary',9254 ,'deepak@219');
insert into manager (fname, lname, phone, password) value('abhishek' ,'kharvar',8778 ,'abhishek@219');
select*from manager;
delete from manager where eid=2;
select*from manager;
select cid from cuser lastrow ;